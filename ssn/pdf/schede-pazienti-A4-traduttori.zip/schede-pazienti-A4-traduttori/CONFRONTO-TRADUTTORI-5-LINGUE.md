# Tabella di Revisione per i Traduttori (IT · RO · EN · BN · UR)

Questo file affianca riga per riga il testo originale italiano e le 4 traduzioni (Romeno, Inglese, Bengalese, Urdu) delle Schede Paziente A4 dello Studio Medico Ippocrate (Dott. Emanuel Savianu, Arezzo).

## 1. TITLE
- **IT:** Italiano — Scheda paziente A4 | savianu.it
- **RO:** Română — Fișă pacient A4 | savianu.it
- **EN:** English — Patient sheet A4 | savianu.it
- **BN:** বাংলা — রোগীর তথ্যপত্র A4 | savianu.it
- **UR:** اردو — مریض کے لیے معلوماتی شیٹ A4 | savianu.it

## 2. Badge lingua
- **IT:** Italiano · Pag. 1/2
- **RO:** Română · Pag. 1/2
- **EN:** English · Page 1/2
- **BN:** বাংলা · পৃষ্ঠা ১/২
- **UR:** اردو · صفحہ 1/2

## 3. P1 - Titolo principale (H1)
- **IT:** Come funziona il tuo studio medico
- **RO:** Cum funcționează cabinetul medicului tău
- **EN:** How your doctor's office works
- **BN:** ডাক্তারের চেম্বার কীভাবে কাজ করে?
- **UR:** ڈاکٹر کا کلینک کیسے کام کرتا ہے؟

## 4. P1 - Sottotitolo
- **IT:** Prenota da solo in 1 minuto su Doctolib. Usa il telefono solo per le vere urgenze.
- **RO:** Fă-ți singur programare în 1 minut pe Doctolib. Folosește telefonul doar pentru urgențe reale.
- **EN:** Book by yourself in 1 minute on Doctolib. Use the phone only for real emergencies.
- **BN:** Doctolib-এ মাত্র ১ মিনিটে নিজেই অ্যাপয়েন্টমেন্ট নিন। শুধুমাত্র জরুরি প্রয়োজনে ফোন ব্যবহার করুন।
- **UR:** Doctolib پر صرف 1 منٹ میں خود اپائنٹمنٹ بک کریں۔ فون صرف حقیقی ہنگامی ضرورت کے لیے استعمال کریں۔

## 5. P1 - Didascalia QR
- **IT:** INQUADRA QUI
- **RO:** SCANEAZĂ AICI
- **EN:** SCAN HERE
- **BN:** স্ক্যান করুন
- **UR:** یہاں اسکین کریں

## 6. P1 - Box Doctolib titolo
- **IT:** PRENOTA E SCRIVI SU DOCTOLIB
- **RO:** PROGRAMARE ȘI MESAJE PE DOCTOLIB
- **EN:** BOOK AND WRITE ON DOCTOLIB
- **BN:** DOCTOLIB-এ অ্যাপয়েন্টমেন্ট ও মেসেজ
- **UR:** DOCTOLIB پر اپائنٹمنٹ اور پیغام

## 7. P1 - Doctolib punto 1
- **IT:** Prenota la visita da solo: scegli giorno e ora sull'app Doctolib o sul sito web.
- **RO:** Programează-ți singur consultația: alege ziua și ora în aplicația Doctolib sau pe site.
- **EN:** Book the visit yourself: choose the day and time on the Doctolib app or on the website.
- **BN:** নিজেই অ্যাপয়েন্টমেন্ট বুক করুন: Doctolib অ্যাপ বা ওয়েবসাইটে গিয়ে দিন ও সময় বেছে নিন।
- **UR:** خود اپائنٹمنٹ بک کریں: Doctolib ایپ یا ویب سائٹ پر جا کر دن اور وقت منتخب کریں۔

## 8. P1 - Doctolib punto 2
- **IT:** Ricette per farmaci abituali: invia una richiesta su Doctolib (pronte in circa 2 giorni lavorativi; ritiro in farmacia con Tessera Sanitaria).
- **RO:** Rețete pentru medicamentele obișnuite: trimite o cerere pe Doctolib (gata în circa 2 zile lucrătoare; se ridică de la farmacie cu cardul de sănătate).
- **EN:** Repeat prescriptions: send a request on Doctolib (ready in about 2 working days; collect them at the pharmacy with your health card).
- **BN:** নিয়মিত ওষুধের প্রেসক্রিপশন (Ricetta): Doctolib-এ মেসেজ পাঠান (প্রায় ২ কার্যদিবসের মধ্যে তৈরি হয়; স্বাস্থ্য কার্ড বা Tessera Sanitaria দেখিয়ে ফার্মেসি থেকে নিন)।
- **UR:** معمول کی ادویات کے نسخے (Ricetta): Doctolib پر پیغام بھیجیں (تقریباً 2 کاروباری دنوں میں تیار؛ ہیلتھ کارڈ Tessera Sanitaria دکھا کر فارمیسی سے حاصل کریں)۔

## 9. P1 - Doctolib punto 3
- **IT:** Orari ambulatorio (solo su appuntamento): Lun–Ven 09:30–12:30 e 16:00–19:00.
- **RO:** Program cabinet (doar cu programare): Luni–Vin 09:30–12:30 și 16:00–19:00.
- **EN:** Office hours (by appointment only): Mon–Fri 09:30–12:30 and 16:00–19:00.
- **BN:** চেম্বারের সময় (শুধুমাত্র অ্যাপয়েন্টমেন্টে): সোম–শুক্র 09:30–12:30 এবং 16:00–19:00।
- **UR:** کلینک کے اوقات (صرف اپائنٹمنٹ کے ساتھ): پیر تا جمعہ 09:30–12:30 اور 16:00–19:00 ۔

## 10. P1 - Doctolib link riga
- **IT:** Inquadra il codice con la fotocamera o vai su: prenota.savianu.it
- **RO:** Scanează codul cu camera telefonului sau intră pe: prenota.savianu.it
- **EN:** Scan the code with your camera or go to: prenota.savianu.it
- **BN:** ফোনের ক্যামেরা দিয়ে QR কোডটি স্ক্যান করুন অথবা যান: prenota.savianu.it
- **UR:** فون کے کیمرے سے کوڈ اسکین کریں یا ویب سائٹ کھولیں: prenota.savianu.it

## 11. P1 - Segreteria titolo
- **IT:** Segreteria: 0575 910 904
- **RO:** Secretariat: 0575 910 904
- **EN:** Reception: 0575 910 904
- **BN:** সেক্রেটারি (Segreteria): 0575 910 904
- **UR:** سیکرٹری آفس: 0575 910 904

## 12. P1 - Segreteria testo
- **IT:** CHIAMA SOLO SE: non riesci a usare Doctolib · hai un problema urgente di oggi · non puoi muoverti da casa (chiama la mattina 09:30–10:30 per la visita domiciliare). Non chiamare per ricette abituali.
- **RO:** SUNĂ DOAR DACĂ: nu poți folosi Doctolib · ai o urgență medicală astăzi · nu te poți deplasa de acasă (sună dimineața 09:30–10:30 pentru vizită la domiciliu). Nu suna pentru rețete obișnuite.
- **EN:** CALL ONLY IF: you cannot use Doctolib · you have an urgent problem today · you cannot leave home (call in the morning 09:30–10:30 for a home visit). Do not call for repeat prescriptions.
- **BN:** শুধুমাত্র তখনই কল করুন যদি: আপনি Doctolib ব্যবহার করতে না পারেন · আজই কোনো জরুরি সমস্যা হয় · অসুস্থতার কারণে বাসা থেকে বের হতে না পারেন (হোম ভিজিটের জন্য সকাল 09:30–10:30 -এর মধ্যে কল করুন)। নিয়মিত ওষুধের জন্য কল করবেন না।
- **UR:** صرف اس صورت میں کال کریں جب: آپ Doctolib استعمال نہ کر سکیں · آج ہی کوئی فوری مسئلہ ہو · بیماری کی وجہ سے گھر سے باہر نہ نکل سکیں (گھر پر معائنے کے لیے صبح 09:30–10:30 کے درمیان کال کریں)۔ معمول کے نسخوں کے لیے کال نہ کریں۔

## 13. P1 - Certificato titolo
- **IT:** Certificato INPS e Visite
- **RO:** Certificat INPS și Consultații
- **EN:** INPS Certificate and Visits
- **BN:** কাজের অসুস্থতার সার্টিফিকেট (INPS) ও ভিজিট
- **UR:** بیماری کا سرٹیفکیٹ (INPS) اور معائنہ

## 14. P1 - Certificato testo
- **IT:** Per il certificato di malattia è obbligatoria la visita in studio il primo giorno (la legge vieta di farlo per telefono). A ogni visita porta le scatole di tutti i farmaci che prendi.
- **RO:** Pentru certificatul de concediu medical este obligatorie consultația la cabinet în prima zi (legea interzice eliberarea prin telefon). La fiecare vizită adu cutiile tuturor medicamentelor pe care le iei.
- **EN:** For a sickness certificate the visit at the office on the first day is compulsory (the law forbids doing it by phone). At every visit bring the boxes of all the medicines you take .
- **BN:** অসুস্থতার সার্টিফিকেটের জন্য অসুস্থতার প্রথম দিনেই চেম্বারে এসে ডাক্তার দেখানো বাধ্যতামূলক (ফোনে সার্টিফিকেট দেওয়া আইনত নিষিদ্ধ)। প্রতিবার ভিজিটে আপনার সব ওষুধের বাক্স সাথে আনুন ।
- **UR:** کام سے چھٹی کے سرٹیفکیٹ کے لیے بیماری کے پہلے دن کلینک آ کر معائنہ کروانا لازمی ہے (فون پر سرٹیفکیٹ دینا قانوناً منع ہے)۔ ہر وزٹ پر اپنی تمام ادویات کے ڈبے ساتھ لائیں ۔

## 15. P1 - Triage titolo
- **IT:** Se stai male: chi chiamare e quando
- **RO:** Dacă te simți rău: unde să suni și când
- **EN:** If you feel unwell: who to call and when
- **BN:** অসুস্থ বোধ করলে: কখন এবং কোন নম্বরে কল করবেন
- **UR:** طبیعت خراب ہونے پر: کب اور کس نمبر پر کال کریں

## 16. P1 - Triage Verde etichetta
- **IT:** Farmacia e CUP Toscana
- **RO:** Farmacie și CUP Toscana
- **EN:** Pharmacy and CUP Toscana
- **BN:** ফার্মেসি ও CUP Toscana
- **UR:** فارمیسی اور CUP Toscana

## 17. P1 - Triage Verde testo
- **IT:** Chiedi consiglio in farmacia per disturbi lievi (raffreddore, tosse lieve). Chiama il numero verde CUP o vai in farmacia per prenotare esami e visite specialistiche con l'impegnativa.
- **RO:** Cere sfatul farmacistului pentru probleme ușoare (răceală, tuse ușoară). Sună gratuit la CUP sau mergi la farmacie pentru a programa analize și consultații de specialitate cu trimitere.
- **EN:** Ask for advice at the pharmacy for minor problems (cold, mild cough). Call the free CUP number or go to the pharmacy to book tests and specialist visits with your referral.
- **BN:** হালকা সমস্যার জন্য (সর্দি, হালকা কাশি) ফার্মেসিতে পরামর্শ নিন। ডাক্তারের কাগজ (Impegnativa) দিয়ে রক্ত পরীক্ষা বা বিশেষজ্ঞ ভিজিট বুক করতে বিনামূল্যে CUP নম্বরে কল করুন বা ফার্মেসিতে যান।
- **UR:** معمولی تکالیف (زکام، ہلکی کھانسی) کے لیے فارمیسی سے مشورہ لیں۔ ڈاکٹر کی پرچی (Impegnativa) کے ساتھ ٹیسٹ یا اسپیشلسٹ اپائنٹمنٹ بک کرنے کے لیے مفت CUP نمبر پر کال کریں یا فارمیسی جائیں۔

## 18. P1 - Triage Giallo etichetta
- **IT:** Guardia Medica (24h)
- **RO:** Guardia Medica (24h)
- **EN:** Out-of-hours doctor (24h)
- **BN:** Guardia Medica (২৪ ঘণ্টা)
- **UR:** گارڈیا میڈیکا (24 گھنٹے)

## 19. P1 - Triage Giallo testo
- **IT:** Attiva di notte, sabato, domenica e festivi , o se il medico non c'è. Numero gratuito per problemi urgenti ma non mortali (rilascia anche il certificato di malattia nei festivi).
- **RO:** Activă noaptea, sâmbăta, duminica și de sărbători , sau când medicul tău lipsește. Număr gratuit pentru probleme urgente dar care nu pun viața în pericol (eliberează și certificat medical în zilele nelucrătoare).
- **EN:** Works at night, on Saturday, Sunday and public holidays , or when your doctor is away. Free number for urgent but not life-threatening problems (it also issues sickness certificates on public holidays).
- **BN:** রাত, শনিবার, রবিবার এবং সরকারি ছুটির দিনে অথবা আপনার ডাক্তার না থাকলে চালু থাকে। জরুরি কিন্তু জীবনঘাতী নয় এমন সমস্যার জন্য বিনামূল্যে নম্বর (ছুটির দিনে অসুস্থতার সার্টিফিকেটও দেয়)।
- **UR:** رات کے وقت، ہفتہ، اتوار اور سرکاری تعطیلات میں، یا جب آپ کا ڈاکٹر موجود نہ ہو۔ فوری لیکن غیر جان لیوا مسائل کے لیے مفت نمبر (تعطیلات میں بیماری کا سرٹیفکیٹ بھی جاری کرتا ہے)۔

## 20. P1 - Triage Rosso etichetta
- **IT:** Emergenza grave
- **RO:** Urgență gravă
- **EN:** Serious emergency
- **BN:** গুরুতর জরুরি অবস্থা
- **UR:** شدید ہنگامی حالت

## 21. P1 - Triage Rosso testo
- **IT:** Solo per pericolo di vita: forte dolore al petto, mancanza di respiro, svenimento, paralisi improvvisa, incidente o emorragia grave. Non andare al Pronto Soccorso per problemi lievi.
- **RO:** Doar în pericol de viață: durere puternică în piept, sufocare, leșin, paralizie bruscă, accident sau hemoragie gravă. Nu merge la Urgențe (Pronto Soccorso) pentru probleme ușoare.
- **EN:** Only for danger to life: severe chest pain, difficulty breathing, fainting, sudden paralysis, accident or heavy bleeding. Do not go to the Emergency Room for minor problems.
- **BN:** শুধুমাত্র জীবনের ঝুঁকি থাকলে: তীব্র বুকে ব্যথা, শ্বাসকষ্ট, অজ্ঞান হয়ে যাওয়া, হঠাৎ পক্ষাঘাত, বড় দুর্ঘটনা বা অতিরিক্ত রক্তপাত। সাধারণ সমস্যার জন্য জরুরি বিভাগে (Pronto Soccorso) যাবেন না।
- **UR:** صرف جان کے خطرے کی صورت میں: سینے میں شدید درد، سانس لینے میں دشواری، بے ہوشی، اچانک فالج، سنگین حادثہ یا شدید خون بہنا۔ معمولی مسائل کے لیے ایمرجنسی (Pronto Soccorso) نہ جائیں۔

## 22. P1 - Striscia diritti MMG
- **IT:** Il Medico di Famiglia (MMG) è gratuito e vincolato al segreto professionale. Gira il foglio per i consigli su farmaci e salute.
- **RO:** Medicul de familie (MMG) este gratuit și obligat la păstrarea secretului profesional. Întoarce foaia pentru sfaturi despre medicamente și sănătate.
- **EN:** The Family Doctor (GP) is free of charge and bound by professional secrecy. Turn the sheet over for advice on medicines and health.
- **BN:** পারিবারিক ডাক্তার (MMG) সম্পূর্ণ বিনামূল্যে এবং আপনার সব তথ্য গোপন রাখা হয়। ওষুধ ও স্বাস্থ্য পরামর্শের জন্য পাতাটি উল্টান।
- **UR:** فیملی ڈاکٹر (MMG) کی خدمات مفت ہیں اور آپ کی تمام معلومات صیغۂ راز میں رکھی جاتی ہیں۔ ادویات اور صحت کے مشوروں کے لیے ورق پلٹیں۔

## 23. P2 - Titolo retro
- **IT:** Vivi sano e usa i farmaci in sicurezza
- **RO:** Trăiește sănătos și ia medicamentele în siguranță
- **EN:** Live well and use medicines safely
- **BN:** সুস্থ থাকুন এবং নিরাপদে ওষুধ ব্যবহার করুন
- **UR:** صحت مند رہیں اور ادویات کا محفوظ استعمال کریں

## 24. P2 - Sottotitolo retro
- **IT:** Consigli pratici del tuo Medico di Famiglia · Pag. 2/2
- **RO:** Sfaturi practice de la medicul tău de familie · Pag. 2/2
- **EN:** Practical advice from your Family Doctor · Page 2/2
- **BN:** আপনার পারিবারিক ডাক্তারের ব্যবহারিক পরামর্শ · পৃষ্ঠা ২/২
- **UR:** آپ کے فیملی ڈاکٹر کے عملی مشورے · صفحہ 2/2

## 25. P2 - Sezione 1
- **IT:** 1. Uso sicuro delle medicine e prevenzione
- **RO:** 1. Utilizarea sigură a medicamentelor și prevenție
- **EN:** 1. Safe use of medicines and prevention
- **BN:** ১. নিরাপদে ওষুধ ব্যবহার ও রোগ প্রতিরোধ
- **UR:** 1. ادویات کا محفوظ استعمال اور بیماریوں سے بچاؤ

## 26. P2 - Sezione 2
- **IT:** 2. Alimentazione e movimento quotidiano
- **RO:** 2. Alimentație și mișcare zilnică
- **EN:** 2. Food and daily movement
- **BN:** ২. প্রতিদিনের খাবার ও শারীরিক পরিশ্রম
- **UR:** 2. متوازن غذا اور روزانہ جسمانی حرکت

## 27. P2 - Sezione 3
- **IT:** 3. Benessere della mente e riposo
- **RO:** 3. Echilibrul minții și odihna
- **EN:** 3. Mind wellbeing and rest
- **BN:** ৩. মানসিক সুস্থতা এবং পর্যাপ্ত ঘুম
- **UR:** 3. ذہنی سکون اور بھرپور نیند

## 28. P2 - Card 1 (Farmaci ogni giorno)
- **IT:** Pressione alta, diabete o colesterolo: prendi le medicine ogni giorno anche se ti senti bene. Non sospenderle mai da solo.
- **RO:** Tensiune mare, diabet sau colesterol: ia medicamentele în fiecare zi, chiar dacă te simți bine. Nu întrerupe niciodată tratamentul singur.
- **EN:** High blood pressure, diabetes or cholesterol: take your medicines every day even if you feel well. Never stop them on your own.
- **BN:** উচ্চ রক্তচাপ, ডায়াবেটিস বা কোলেস্টেরল: আপনি সুস্থ বোধ করলেও প্রতিদিন নিয়মিত ওষুধ খান। ডাক্তারের পরামর্শ ছাড়া নিজে থেকে কখনো ওষুধ বন্ধ করবেন না।
- **UR:** بلڈ پریشر، شوگر (ذیابیطس) یا کولیسٹرول: اگر آپ بہتر محسوس کر رہے ہوں تب بھی اپنی دوا روزانہ لیں۔ ڈاکٹر کے مشورے کے بغیر دوا کبھی بند نہ کریں۔

## 29. P2 - Card 2 (Antibiotici)
- **IT:** Prendili solo se li prescrive il medico (non servono per virus, raffreddore o influenza). Finisci sempre tutta la scatola.
- **RO:** Ia-le doar dacă sunt prescrise de medic (nu ajută la virusuri, răceală sau gripă). Termină întotdeauna toată cutia prescrisă.
- **EN:** Take them only if the doctor prescribes them (they do not work for viruses, colds or flu). Always finish the whole box.
- **BN:** শুধুমাত্র ডাক্তার প্রেসক্রাইব করলেই খান (ভাইরাস, সাধারণ সর্দি বা জ্বরে কাজ করে না)। জ্বর বা ব্যথা কমে গেলেও সর্বদা পুরো কোর্স শেষ করুন।
- **UR:** صرف ڈاکٹر کے نسخے پر استعمال کریں (وائرس، زکام یا فلو میں اثر نہیں کرتیں)۔ بخار یا درد ختم ہونے پر بھی پورا کورس مکمل کریں۔

## 30. P2 - Card 3 (Erbe e rimedi tradizionali)
- **IT:** Avvisa sempre il medico se usi tisane, erbe, integratori o medicine tradizionali: possono alterare l'effetto dei farmaci.
- **RO:** Spune mereu medicului dacă iei ceaiuri medicinale, plante, suplimente sau remedii tradiționale: pot schimba efectul medicamentelor.
- **EN:** Always tell your doctor if you use herbal teas, herbs, supplements or traditional medicines: they can change the effect of your medicines.
- **BN:** আপনি যদি প্রাকৃতিক ভেষজ, হার্বাল চা, ঐতিহ্যবাহী ওষুধ বা সাপ্লিমেন্ট ব্যবহার করেন তবে অবশ্যই ডাক্তারকে জানান: এগুলো ওষুধের কার্যকারিতা বদলে দিতে পারে।
- **UR:** اگر آپ قہوے، جڑی بوٹیاں، سپلیمنٹس یا روایتی ادویات استعمال کرتے ہیں تو ڈاکٹر کو ضرور بتائیں: یہ ادویات کے اثر کو بدل سکتی ہیں۔

## 31. P2 - Card 4 (Vaccini e screening gratuiti)
- **IT:** Proteggono te e la tua famiglia dalle malattie gravi. Chiedi al medico quali vaccini e controlli gratuiti sono indicati per te.
- **RO:** Te protejează pe tine și familia ta de boli grave. Întreabă medicul ce vaccinuri și controale gratuite sunt recomandate pentru tine.
- **EN:** They protect you and your family from serious diseases. Ask the doctor which vaccines and free check-ups are right for you.
- **BN:** টিকা আপনাকে ও আপনার পরিবারকে মারাত্মক রোগ থেকে রক্ষা করে। আপনার জন্য কোন কোন টিকা ও বিনামূল্যে স্বাস্থ্য পরীক্ষা প্রয়োজন তা ডাক্তারের কাছে জানতে চান।
- **UR:** یہ آپ کو اور آپ کے خاندان کو سنگین بیماریوں سے بچاتی ہیں۔ اپنے ڈاکٹر سے پوچھیں کہ آپ کے لیے کون سی ویکسین اور مفت معائنے ضروری ہیں۔

## 32. P2 - Card 5 (Piatto sano ogni giorno)
- **IT:** Mangia più verdure a foglia verde, legumi (lenticchie, ceci) e cereali integrali. Riduci riso bianco, pane bianco, fritture e dolci.
- **RO:** Mănâncă mai multe legume verzi, leguminoase (linte, năut, fasole) și cereale integrale. Redu orezul alb, pâinea albă, prăjelile și dulciurile.
- **EN:** Eat more green leafy vegetables, pulses (lentils, chickpeas) and wholegrains. Cut down on white rice, white bread, fried food and sweets.
- **BN:** বেশি করে সবুজ শাকসবজি, ডাল (মসুর, ছোলা) এবং লাল আটা বা গোটা শস্য খান। অতিরিক্ত সাদা ভাত, সাদা রুটি, ভাজাপোড়া ও মিষ্টি খাওয়া কমান।
- **UR:** ہری سبزیاں، دالیں (مسور، چنے) اور بغیر چھنا آٹا زیادہ کھائیں۔ سفید چاول، سفید ڈبل روٹی، تلی ہوئی اشیاء اور مٹھائیاں کم کریں۔

## 33. P2 - Card 6 (Poco sale, più spezie)
- **IT:** Troppo sale alza la pressione. Usa spezie, aglio, limone ed erbe aromatiche naturali per dare sapore ai cibi.
- **RO:** Prea multă sare crește tensiunea arterială. Folosește condimente, usturoi, lămâie și ierburi aromatice naturale pentru gust.
- **EN:** Too much salt raises blood pressure. Use spices, garlic, lemon and natural herbs to flavour your food.
- **BN:** অতিরিক্ত লবণ রক্তচাপ বাড়ায়। খাবারে স্বাদ আনতে লবণের বদলে প্রাকৃতিক মশলা, রসুন, লেবু এবং সুগন্ধি ভেষজ ব্যবহার করুন।
- **UR:** زیادہ نمک بلڈ پریشر بڑھاتا ہے۔ کھانے میں ذائقے کے لیے نمک کے بجائے قدرتی مصالحے، لہسن، لیموں اور خوشبودار جڑی بوٹیاں استعمال کریں۔

## 34. P2 - Card 7 (Bevi acqua naturale)
- **IT:** Bevi 1,5–2 litri di acqua al giorno. Evita bibite gassate, tè zuccherati e succhi di frutta confezionati (contengono molto zucchero).
- **RO:** Bea 1,5–2 litri de apă pe zi. Evită băuturile acidulate, ceaiurile îndulcite și sucurile din comerț (conțin foarte mult zahăr).
- **EN:** Drink 1.5–2 litres of water a day. Avoid fizzy drinks, sweetened tea and packaged fruit juices (they contain a lot of sugar).
- **BN:** প্রতিদিন অন্তত ১.৫ থেকে ২ লিটার পানি পান করুন। গ্যাসযুক্ত কোমল পানীয় (সফট ড্রিংকস), মিষ্টি চা এবং প্যাকেটজাত ফলের রস এড়িয়ে চলুন।
- **UR:** روزانہ کم از کم 1.5 سے 2 لیٹر پانی پیئیں۔ گیس والے مشروبات (سوفٹ ڈرنکس)، میٹھی چائے اور ڈبے کے جوس سے پرہیز کریں۔

## 35. P2 - Card 8 (Muoviti 30 minuti al giorno)
- **IT:** Cammina a passo svelto ogni giorno: abbassa la glicemia, regola la pressione, controlla il peso e riduce lo stress.
- **RO:** Mergi pe jos în pas vioi în fiecare zi: scade glicemia, reglează tensiunea, controlează greutatea și reduce stresul.
- **EN:** Walk briskly every day: it lowers blood sugar, regulates blood pressure, controls weight and reduces stress.
- **BN:** প্রতিদিন অন্তত ৩০ মিনিট দ্রুত গতিতে হাঁটুন: এটি রক্তের সুগার ও রক্তচাপ কমায়, ওজন নিয়ন্ত্রণে রাখে এবং মানসিক চাপ দূর করে।
- **UR:** ہر روز تیز قدموں سے چہل قدمی کریں: اس سے شوگر اور بلڈ پریشر کنٹرول میں رہتا ہے، وزن کم ہوتا ہے اور ذہنی تناؤ گھٹتا ہے۔

## 36. P2 - Card 9 (Anche la mente si cura)
- **IT:** Tristezza, ansia o stanchezza profonda non sono una colpa. Se non riesci più a fare le cose di sempre, parlane senza paura col tuo medico.
- **RO:** Tristețea, anxietatea sau oboseala profundă nu sunt o rușine. Dacă nu mai poți face lucrurile obișnuite, vorbește fără teamă cu medicul tău.
- **EN:** Sadness, anxiety or deep tiredness are not your fault. If you can no longer do your usual things, talk to your doctor without fear.
- **BN:** মন খারাপ, দুশ্চিন্তা বা অতিরিক্ত ক্লান্তি কোনো লজ্জার বিষয় নয়। যদি প্রতিদিনের স্বাভাবিক কাজ করতে কষ্ট হয়, তবে নিঃসংকোচে আপনার ডাক্তারের সাথে কথা বলুন।
- **UR:** اداسی، پریشانی یا شدید تھکن کوئی عیب نہیں۔ اگر آپ روزمرہ کے کام نہیں کر پا رہے تو بلا جھجھک اپنے ڈاکٹر سے بات کریں۔

## 37. P2 - Card 10 (Dormi 7–8 ore e datti un ritmo)
- **IT:** Il sonno ripara mente e corpo. Mantieni orari regolari, spegni gli schermi del telefono prima di dormire e prendi aria ogni giorno.
- **RO:** Somnul repară mintea și corpul. Păstrează ore regulate, închide ecranul telefonului înainte de culcare și ieși la aer în fiecare zi.
- **EN:** Sleep repairs mind and body. Keep regular hours, turn off phone screens before bed and get some fresh air every day.
- **BN:** ভালো ঘুম শরীর ও মনকে সুস্থ রাখে। প্রতিদিন নির্দিষ্ট সময়ে ঘুমান, ঘুমানোর আগে ফোনের স্ক্রিন বন্ধ রাখুন এবং প্রতিদিন কিছুক্ষণ খোলা হাওয়ায় হাঁটুন।
- **UR:** نیند جسم اور دماغ کو توانائی دیتی ہے۔ سونے کے اوقات مقرر رکھیں، سونے سے پہلے موبائل اسکرین بند کر دیں اور روزانہ تازہ ہوا میں وقت گزاریں۔

## 38. P2 - Fascia emergenza fondo
- **IT:** Emergenza grave: 112 · Guardia Medica (notte e festivi): 116 117 · Ascolto (Telefono Amico): 02 2327 2327
- **RO:** Urgență gravă: 112 · Guardia Medica (noaptea și sărbători): 116 117 · Ascultare (Telefono Amico): 02 2327 2327
- **EN:** Serious emergency: 112 · Out-of-hours doctor (night and holidays): 116 117 · Listening (Telefono Amico): 02 2327 2327
- **BN:** গুরুতর জরুরি অবস্থা: 112 · Guardia Medica (রাত ও ছুটির দিন): 116 117 · মানসিক সহায়তা (Telefono Amico): 02 2327 2327
- **UR:** شدید ایمرجنسی: 112 · گارڈیا میڈیکا (رات اور تعطیلات): 116 117 · ہیلپ لائن (Telefono Amico): 02 2327 2327

