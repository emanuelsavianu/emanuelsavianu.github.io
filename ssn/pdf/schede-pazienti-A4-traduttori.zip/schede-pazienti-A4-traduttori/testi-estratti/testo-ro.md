# Testo Scheda Paziente A4 — RO

### TITLE
Română — Fișă pacient A4 | savianu.it

### Badge lingua
Română · Pag. 1/2

### P1 - Titolo principale (H1)
Cum funcționează cabinetul medicului tău

### P1 - Sottotitolo
Fă-ți singur programare în 1 minut pe Doctolib. Folosește telefonul doar pentru urgențe reale.

### P1 - Didascalia QR
SCANEAZĂ AICI

### P1 - Box Doctolib titolo
PROGRAMARE ȘI MESAJE PE DOCTOLIB

### P1 - Doctolib punto 1
Programează-ți singur consultația: alege ziua și ora în aplicația Doctolib sau pe site.

### P1 - Doctolib punto 2
Rețete pentru medicamentele obișnuite: trimite o cerere pe Doctolib (gata în circa 2 zile lucrătoare; se ridică de la farmacie cu cardul de sănătate).

### P1 - Doctolib punto 3
Program cabinet (doar cu programare): Luni–Vin 09:30–12:30 și 16:00–19:00.

### P1 - Doctolib link riga
Scanează codul cu camera telefonului sau intră pe: prenota.savianu.it

### P1 - Segreteria titolo
Secretariat: 0575 910 904

### P1 - Segreteria testo
SUNĂ DOAR DACĂ: nu poți folosi Doctolib · ai o urgență medicală astăzi · nu te poți deplasa de acasă (sună dimineața 09:30–10:30 pentru vizită la domiciliu). Nu suna pentru rețete obișnuite.

### P1 - Certificato titolo
Certificat INPS și Consultații

### P1 - Certificato testo
Pentru certificatul de concediu medical este obligatorie consultația la cabinet în prima zi (legea interzice eliberarea prin telefon). La fiecare vizită adu cutiile tuturor medicamentelor pe care le iei.

### P1 - Triage titolo
Dacă te simți rău: unde să suni și când

### P1 - Triage Verde etichetta
Farmacie și CUP Toscana

### P1 - Triage Verde testo
Cere sfatul farmacistului pentru probleme ușoare (răceală, tuse ușoară). Sună gratuit la CUP sau mergi la farmacie pentru a programa analize și consultații de specialitate cu trimitere.

### P1 - Triage Giallo etichetta
Guardia Medica (24h)

### P1 - Triage Giallo testo
Activă noaptea, sâmbăta, duminica și de sărbători , sau când medicul tău lipsește. Număr gratuit pentru probleme urgente dar care nu pun viața în pericol (eliberează și certificat medical în zilele nelucrătoare).

### P1 - Triage Rosso etichetta
Urgență gravă

### P1 - Triage Rosso testo
Doar în pericol de viață: durere puternică în piept, sufocare, leșin, paralizie bruscă, accident sau hemoragie gravă. Nu merge la Urgențe (Pronto Soccorso) pentru probleme ușoare.

### P1 - Striscia diritti MMG
Medicul de familie (MMG) este gratuit și obligat la păstrarea secretului profesional. Întoarce foaia pentru sfaturi despre medicamente și sănătate.

### P2 - Titolo retro
Trăiește sănătos și ia medicamentele în siguranță

### P2 - Sottotitolo retro
Sfaturi practice de la medicul tău de familie · Pag. 2/2

### P2 - Sezione 1
1. Utilizarea sigură a medicamentelor și prevenție

### P2 - Sezione 2
2. Alimentație și mișcare zilnică

### P2 - Sezione 3
3. Echilibrul minții și odihna

### P2 - Card 1 (Medicamente în fiecare zi)
Tensiune mare, diabet sau colesterol: ia medicamentele în fiecare zi, chiar dacă te simți bine. Nu întrerupe niciodată tratamentul singur.

### P2 - Card 2 (Antibiotice)
Ia-le doar dacă sunt prescrise de medic (nu ajută la virusuri, răceală sau gripă). Termină întotdeauna toată cutia prescrisă.

### P2 - Card 3 (Plante și remedii tradiționale)
Spune mereu medicului dacă iei ceaiuri medicinale, plante, suplimente sau remedii tradiționale: pot schimba efectul medicamentelor.

### P2 - Card 4 (Vaccinuri și screening gratuit)
Te protejează pe tine și familia ta de boli grave. Întreabă medicul ce vaccinuri și controale gratuite sunt recomandate pentru tine.

### P2 - Card 5 (Farfurie sănătoasă zilnic)
Mănâncă mai multe legume verzi, leguminoase (linte, năut, fasole) și cereale integrale. Redu orezul alb, pâinea albă, prăjelile și dulciurile.

### P2 - Card 6 (Puțină sare, mai multe condimente)
Prea multă sare crește tensiunea arterială. Folosește condimente, usturoi, lămâie și ierburi aromatice naturale pentru gust.

### P2 - Card 7 (Bea apă simplă)
Bea 1,5–2 litri de apă pe zi. Evită băuturile acidulate, ceaiurile îndulcite și sucurile din comerț (conțin foarte mult zahăr).

### P2 - Card 8 (Mișcă-te 30 de minute pe zi)
Mergi pe jos în pas vioi în fiecare zi: scade glicemia, reglează tensiunea, controlează greutatea și reduce stresul.

### P2 - Card 9 (Și mintea se poate vindeca)
Tristețea, anxietatea sau oboseala profundă nu sunt o rușine. Dacă nu mai poți face lucrurile obișnuite, vorbește fără teamă cu medicul tău.

### P2 - Card 10 (Dormi 7–8 ore și păstrează un ritm)
Somnul repară mintea și corpul. Păstrează ore regulate, închide ecranul telefonului înainte de culcare și ieși la aer în fiecare zi.

### P2 - Fascia emergenza fondo
Urgență gravă: 112 · Guardia Medica (noaptea și sărbători): 116 117 · Ascultare (Telefono Amico): 02 2327 2327

