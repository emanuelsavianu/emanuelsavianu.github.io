# Testo Scheda Paziente A4 — EN

### TITLE
English — Patient sheet A4 | savianu.it

### Badge lingua
English · Page 1/2

### P1 - Titolo principale (H1)
How your doctor's office works

### P1 - Sottotitolo
Book by yourself in 1 minute on Doctolib. Use the phone only for real emergencies.

### P1 - Didascalia QR
SCAN HERE

### P1 - Box Doctolib titolo
BOOK AND WRITE ON DOCTOLIB

### P1 - Doctolib punto 1
Book the visit yourself: choose the day and time on the Doctolib app or on the website.

### P1 - Doctolib punto 2
Repeat prescriptions: send a request on Doctolib (ready in about 2 working days; collect them at the pharmacy with your health card).

### P1 - Doctolib punto 3
Office hours (by appointment only): Mon–Fri 09:30–12:30 and 16:00–19:00.

### P1 - Doctolib link riga
Scan the code with your camera or go to: prenota.savianu.it

### P1 - Segreteria titolo
Reception: 0575 910 904

### P1 - Segreteria testo
CALL ONLY IF: you cannot use Doctolib · you have an urgent problem today · you cannot leave home (call in the morning 09:30–10:30 for a home visit). Do not call for repeat prescriptions.

### P1 - Certificato titolo
INPS Certificate and Visits

### P1 - Certificato testo
For a sickness certificate the visit at the office on the first day is compulsory (the law forbids doing it by phone). At every visit bring the boxes of all the medicines you take .

### P1 - Triage titolo
If you feel unwell: who to call and when

### P1 - Triage Verde etichetta
Pharmacy and CUP Toscana

### P1 - Triage Verde testo
Ask for advice at the pharmacy for minor problems (cold, mild cough). Call the free CUP number or go to the pharmacy to book tests and specialist visits with your referral.

### P1 - Triage Giallo etichetta
Out-of-hours doctor (24h)

### P1 - Triage Giallo testo
Works at night, on Saturday, Sunday and public holidays , or when your doctor is away. Free number for urgent but not life-threatening problems (it also issues sickness certificates on public holidays).

### P1 - Triage Rosso etichetta
Serious emergency

### P1 - Triage Rosso testo
Only for danger to life: severe chest pain, difficulty breathing, fainting, sudden paralysis, accident or heavy bleeding. Do not go to the Emergency Room for minor problems.

### P1 - Striscia diritti MMG
The Family Doctor (GP) is free of charge and bound by professional secrecy. Turn the sheet over for advice on medicines and health.

### P2 - Titolo retro
Live well and use medicines safely

### P2 - Sottotitolo retro
Practical advice from your Family Doctor · Page 2/2

### P2 - Sezione 1
1. Safe use of medicines and prevention

### P2 - Sezione 2
2. Food and daily movement

### P2 - Sezione 3
3. Mind wellbeing and rest

### P2 - Card 1 (Medicines every day)
High blood pressure, diabetes or cholesterol: take your medicines every day even if you feel well. Never stop them on your own.

### P2 - Card 2 (Antibiotics)
Take them only if the doctor prescribes them (they do not work for viruses, colds or flu). Always finish the whole box.

### P2 - Card 3 (Herbs and traditional remedies)
Always tell your doctor if you use herbal teas, herbs, supplements or traditional medicines: they can change the effect of your medicines.

### P2 - Card 4 (Free vaccines and screening)
They protect you and your family from serious diseases. Ask the doctor which vaccines and free check-ups are right for you.

### P2 - Card 5 (A healthy plate every day)
Eat more green leafy vegetables, pulses (lentils, chickpeas) and wholegrains. Cut down on white rice, white bread, fried food and sweets.

### P2 - Card 6 (Less salt, more spices)
Too much salt raises blood pressure. Use spices, garlic, lemon and natural herbs to flavour your food.

### P2 - Card 7 (Drink plain water)
Drink 1.5–2 litres of water a day. Avoid fizzy drinks, sweetened tea and packaged fruit juices (they contain a lot of sugar).

### P2 - Card 8 (Move for 30 minutes a day)
Walk briskly every day: it lowers blood sugar, regulates blood pressure, controls weight and reduces stress.

### P2 - Card 9 (Your mind needs care too)
Sadness, anxiety or deep tiredness are not your fault. If you can no longer do your usual things, talk to your doctor without fear.

### P2 - Card 10 (Sleep 7–8 hours and keep a routine)
Sleep repairs mind and body. Keep regular hours, turn off phone screens before bed and get some fresh air every day.

### P2 - Fascia emergenza fondo
Serious emergency: 112 · Out-of-hours doctor (night and holidays): 116 117 · Listening (Telefono Amico): 02 2327 2327

