# Testo Scheda Paziente A4 — IT

### TITLE
Italiano — Scheda paziente A4 | savianu.it

### Badge lingua
Italiano · Pag. 1/2

### P1 - Titolo principale (H1)
Come funziona il tuo studio medico

### P1 - Sottotitolo
Prenota da solo in 1 minuto su Doctolib. Usa il telefono solo per le vere urgenze.

### P1 - Didascalia QR
INQUADRA QUI

### P1 - Box Doctolib titolo
PRENOTA E SCRIVI SU DOCTOLIB

### P1 - Doctolib punto 1
Prenota la visita da solo: scegli giorno e ora sull'app Doctolib o sul sito web.

### P1 - Doctolib punto 2
Ricette per farmaci abituali: invia una richiesta su Doctolib (pronte in circa 2 giorni lavorativi; ritiro in farmacia con Tessera Sanitaria).

### P1 - Doctolib punto 3
Orari ambulatorio (solo su appuntamento): Lun–Ven 09:30–12:30 e 16:00–19:00.

### P1 - Doctolib link riga
Inquadra il codice con la fotocamera o vai su: prenota.savianu.it

### P1 - Segreteria titolo
Segreteria: 0575 910 904

### P1 - Segreteria testo
CHIAMA SOLO SE: non riesci a usare Doctolib · hai un problema urgente di oggi · non puoi muoverti da casa (chiama la mattina 09:30–10:30 per la visita domiciliare). Non chiamare per ricette abituali.

### P1 - Certificato titolo
Certificato INPS e Visite

### P1 - Certificato testo
Per il certificato di malattia è obbligatoria la visita in studio il primo giorno (la legge vieta di farlo per telefono). A ogni visita porta le scatole di tutti i farmaci che prendi.

### P1 - Triage titolo
Se stai male: chi chiamare e quando

### P1 - Triage Verde etichetta
Farmacia e CUP Toscana

### P1 - Triage Verde testo
Chiedi consiglio in farmacia per disturbi lievi (raffreddore, tosse lieve). Chiama il numero verde CUP o vai in farmacia per prenotare esami e visite specialistiche con l'impegnativa.

### P1 - Triage Giallo etichetta
Guardia Medica (24h)

### P1 - Triage Giallo testo
Attiva di notte, sabato, domenica e festivi , o se il medico non c'è. Numero gratuito per problemi urgenti ma non mortali (rilascia anche il certificato di malattia nei festivi).

### P1 - Triage Rosso etichetta
Emergenza grave

### P1 - Triage Rosso testo
Solo per pericolo di vita: forte dolore al petto, mancanza di respiro, svenimento, paralisi improvvisa, incidente o emorragia grave. Non andare al Pronto Soccorso per problemi lievi.

### P1 - Striscia diritti MMG
Il Medico di Famiglia (MMG) è gratuito e vincolato al segreto professionale. Gira il foglio per i consigli su farmaci e salute.

### P2 - Titolo retro
Vivi sano e usa i farmaci in sicurezza

### P2 - Sottotitolo retro
Consigli pratici del tuo Medico di Famiglia · Pag. 2/2

### P2 - Sezione 1
1. Uso sicuro delle medicine e prevenzione

### P2 - Sezione 2
2. Alimentazione e movimento quotidiano

### P2 - Sezione 3
3. Benessere della mente e riposo

### P2 - Card 1 (Farmaci ogni giorno)
Pressione alta, diabete o colesterolo: prendi le medicine ogni giorno anche se ti senti bene. Non sospenderle mai da solo.

### P2 - Card 2 (Antibiotici)
Prendili solo se li prescrive il medico (non servono per virus, raffreddore o influenza). Finisci sempre tutta la scatola.

### P2 - Card 3 (Erbe e rimedi tradizionali)
Avvisa sempre il medico se usi tisane, erbe, integratori o medicine tradizionali: possono alterare l'effetto dei farmaci.

### P2 - Card 4 (Vaccini e screening gratuiti)
Proteggono te e la tua famiglia dalle malattie gravi. Chiedi al medico quali vaccini e controlli gratuiti sono indicati per te.

### P2 - Card 5 (Piatto sano ogni giorno)
Mangia più verdure a foglia verde, legumi (lenticchie, ceci) e cereali integrali. Riduci riso bianco, pane bianco, fritture e dolci.

### P2 - Card 6 (Poco sale, più spezie)
Troppo sale alza la pressione. Usa spezie, aglio, limone ed erbe aromatiche naturali per dare sapore ai cibi.

### P2 - Card 7 (Bevi acqua naturale)
Bevi 1,5–2 litri di acqua al giorno. Evita bibite gassate, tè zuccherati e succhi di frutta confezionati (contengono molto zucchero).

### P2 - Card 8 (Muoviti 30 minuti al giorno)
Cammina a passo svelto ogni giorno: abbassa la glicemia, regola la pressione, controlla il peso e riduce lo stress.

### P2 - Card 9 (Anche la mente si cura)
Tristezza, ansia o stanchezza profonda non sono una colpa. Se non riesci più a fare le cose di sempre, parlane senza paura col tuo medico.

### P2 - Card 10 (Dormi 7–8 ore e datti un ritmo)
Il sonno ripara mente e corpo. Mantieni orari regolari, spegni gli schermi del telefono prima di dormire e prendi aria ogni giorno.

### P2 - Fascia emergenza fondo
Emergenza grave: 112 · Guardia Medica (notte e festivi): 116 117 · Ascolto (Telefono Amico): 02 2327 2327

